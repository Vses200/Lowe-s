public class Store {

private String BrandName;
private String ProductCode;
private int Price;
private int ProductUnits;
private int NumberOfSales;
private int DaysInStock;

public String getBrandName() {
    return BrandName;
}

public String getProductCode() {
    return ProductCode;
}

public int getPrice() {
    return Price;
}

public int getProductUnits() {
    return ProductUnits;
}

public int getNumberOfSales() {
    return NumberOfSales;
}


public int getDaysInStock() {
    return DaysInStock;
}




public Store(String BrandName, String ProductCode, int Price, int ProductUnits , int NumberOfSales, int DaysInStock) {
    super();
    this.BrandName = BrandName;
    this.ProductCode = ProductCode;
    this.Price = Price;
    this.ProductUnits = ProductUnits;
	this.NumberOfSales = NumberOfSales;
	this.DaysInStock = DaysInStock;
}
}