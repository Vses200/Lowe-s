import java.util.*;

public class StoreInventory {

private static final int INVENTORY_SIZE = 4;
private static Store [] Stores = new Store [INVENTORY_SIZE];


/*public  StoreInventory() {
    Stores = new Store [INVENTORY_SIZE];

	}*/

private static void Store_Inventory() {
		
	
       for (int i = 0; i<=INVENTORY_SIZE; i++){
		   
         Scanner console = new Scanner(System.in);

    System.out.println ("Brand Name");
    String BrandsName = console.next();

    System.out.println ("Product Code");
    String ProductCode= console.next();

    System.out.println ("Product's price:");
    int ProductPrice = console.nextInt();
	 
	System.out.println ("Product Uni ts");
    int ProductUnits= console.nextInt();


    System.out.println ("No. of Sales");
    int NumberOfSales= console.nextInt();
	
	System.out.println ("Days in Stock");
    int DaysInStock= console.nextInt();

          Stores [i]= new Store(BrandsName, ProductCode, ProductPrice, ProductUnits, NumberOfSales, DaysInStock);
		  
		  
    	System.out.println("\n\nDo you want to enter?(Y/N)");
		   String check = console.next();
					if(!check.equals("y"))
						break;
	   }				 
		  
	   
}

public static void main (String[] args){
    //StoreInventory();
	double[] NewPrice=new double[100];
	Store_Inventory();
	
	System.out.println("Brand    code    Price    Units    Sales      No. of Units to be replenished         DaysInStock       New Price");
		for(int i=0;i<=Stores.length;i++){
				
				
				
				if(Stores[i].getDaysInStock()>180)
					NewPrice[i]= Stores[i].getPrice() - 0.5*Stores[i].getPrice();
				else if(Stores[i].getDaysInStock()>90 && Stores[i].getDaysInStock()<180)
					NewPrice[i]=Stores[i].getPrice() - 0.3*Stores[i].getPrice();
				else if(Stores[i].getDaysInStock()>60 && Stores[i].getDaysInStock()<90)
					NewPrice[i]=Stores[i].getPrice() - 0.1*Stores[i].getPrice();
				else
					NewPrice[i]= Stores[i].getPrice();
				
			System.out.print("\n"+Stores [i].getBrandName()+"    "+Stores [i].getProductCode()+"    "+Stores [i].getPrice()+"    "+Stores [i].getProductUnits()+"    "+Stores [i].getNumberOfSales()+"       "+(Stores[i].getProductUnits()-Stores[i].getNumberOfSales()));
			System.out.println("    "+Stores[i].getDaysInStock()+"    "+NewPrice[i]);		
		}
	}
}